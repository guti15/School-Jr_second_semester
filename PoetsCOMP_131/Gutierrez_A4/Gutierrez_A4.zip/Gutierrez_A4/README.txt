* Program A4_Gutierrez :  Tall Elf

** Content: 
   1. TallElf.py
   2. Tolkien_File
   3. Tall Elf Collected Data.xlsx
   4. Tall Elf Documentation.docx



** Description: 
  * Matching to Content(above)
   1) Python Program where we can commit changes to add elf names or adjectives.

   2) A Directory which holds text files for the Tolkien Collection as well as a small test file.

   3) The Excel work sheet which holds the raw physical numbers collected from the program

   4) A Summery of what we saw in the Data collected as well as table of the numbers collected. 
